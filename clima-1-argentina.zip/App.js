import React, { useEffect, useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";

// Diccionario simple de íconos según código WMO
const ICONOS = {
  0: "sunny",
  1: "partly-sunny",
  2: "cloudy",
  3: "cloudy",
  61: "rainy",
  63: "rainy",
  65: "rainy",
  71: "snow",
  73: "snow",
  75: "snow",
  80: "rainy",
  81: "rainy",
  82: "rainy",
  95: "thunderstorm",
  96: "thunderstorm",
  99: "thunderstorm",
};

const WMO_ES = {
  0: "Despejado",
  1: "Mayormente despejado",
  2: "Parcialmente nublado",
  3: "Nublado",
  61: "Lluvia ligera",
  63: "Lluvia moderada",
  65: "Lluvia fuerte",
  71: "Nieve ligera",
  73: "Nieve moderada",
  75: "Nieve fuerte",
  80: "Chubascos ligeros",
  81: "Chubascos",
  82: "Chubascos fuertes",
  95: "Tormenta",
  96: "Tormenta fuerte",
  99: "Tormenta muy fuerte",
};

function codeToText(code) {
  return WMO_ES[code] || `Condición (${code})`;
}

function codeToIcon(code) {
  return ICONOS[code] || "help";
}

// Buscar ciudades en Argentina
async function geocodeAR(query) {
  const url = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(
    query
  )}&country=AR&count=5&language=es`;
  const res = await fetch(url);
  const data = await res.json();
  return data.results ?? [];
}

// Obtener clima
async function getForecast({ latitude, longitude }) {
  const url = `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=temperature_2m,weather_code,wind_speed_10m,relative_humidity_2m&daily=temperature_2m_max,temperature_2m_min,weather_code,precipitation_probability_max&timezone=auto`;
  const res = await fetch(url);
  return res.json();
}

export default function App() {
  const [query, setQuery] = useState("");
  const [places, setPlaces] = useState([]);
  const [place, setPlace] = useState(null);
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);

  // Buscar ciudades
  useEffect(() => {
    const timer = setTimeout(async () => {
      if (query.length > 2) {
        try {
          const res = await geocodeAR(query);
          setPlaces(res);
        } catch {
          setPlaces([]);
        }
      } else {
        setPlaces([]);
      }
    }, 400);
    return () => clearTimeout(timer);
  }, [query]);

  // Cargar clima al elegir ciudad
  useEffect(() => {
    if (!place) return;
    (async () => {
      setLoading(true);
      const d = await getForecast(place);
      setData(d);
      setLoading(false);
    })();
  }, [place]);

  const current = data?.current;
  const daily = data?.daily;

  return (
    <LinearGradient colors={["#4facfe", "#00f2fe"]} style={styles.container}>
      <Text style={styles.title}>☀️ Clima Argentina</Text>
      <TextInput
        style={styles.input}
        placeholder="Buscar ciudad..."
        value={query}
        onChangeText={setQuery}
      />
      {places.map((p) => (
        <TouchableOpacity
          key={p.id}
          style={styles.placeButton}
          onPress={() => setPlace(p)}
        >
          <Text style={styles.placeText}>
            {p.name}, {p.admin1}
          </Text>
        </TouchableOpacity>
      ))}
      {loading && <ActivityIndicator size="large" color="#fff" />}
      {current && !loading && (
        <View style={styles.card}>
          <Text style={styles.city}>
            {place?.name}, {place?.admin1}
          </Text>
          <Ionicons
            name={codeToIcon(current.weather_code)}
            size={64}
            color="white"
          />
          <Text style={styles.temp}>{current.temperature_2m}°C</Text>
          <Text style={styles.desc}>{codeToText(current.weather_code)}</Text>
          <Text style={styles.info}>💨 {current.wind_speed_10m} km/h</Text>
          <Text style={styles.info}>💧 {current.relative_humidity_2m}%</Text>
        </View>
      )}
      {daily && !loading && (
        <ScrollView style={{ marginTop: 20 }}>
          <Text style={styles.subtitle}>Próximos días</Text>
          {daily.time.map((t, i) => (
            <View key={i} style={styles.dayCard}>
              <Text style={{ flex: 1 }}>
                {new Date(t).toLocaleDateString("es-AR", {
                  weekday: "short",
                  day: "numeric",
                  month: "short",
                })}
              </Text>
              <Ionicons
                name={codeToIcon(daily.weather_code[i])}
                size={28}
                color="#333"
                style={{ flex: 1, textAlign: "center" }}
              />
              <Text style={{ flex: 1, textAlign: "right" }}>
                {Math.round(daily.temperature_2m_max[i])}° /{" "}
                {Math.round(daily.temperature_2m_min[i])}°
              </Text>
            </View>
          ))}
        </ScrollView>
      )}
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: "center", padding: 20 },
  title: { fontSize: 26, fontWeight: "bold", color: "white", marginVertical: 20 },
  input: {
    backgroundColor: "white",
    borderRadius: 8,
    padding: 10,
    width: "100%",
    marginBottom: 10,
  },
  placeButton: {
    backgroundColor: "#fff3",
    padding: 10,
    marginVertical: 5,
    borderRadius: 8,
  },
  placeText: { color: "white", fontSize: 16 },
  card: {
    backgroundColor: "#ffffff33",
    padding: 20,
    borderRadius: 16,
    marginTop: 20,
    alignItems: "center",
    width: "100%",
  },
  city: { fontSize: 20, fontWeight: "bold", color: "white" },
  temp: { fontSize: 48, fontWeight: "bold", color: "white" },
  desc: { fontSize: 20, color: "white" },
  info: { fontSize: 16, color: "white" },
  subtitle: { fontSize: 20, fontWeight: "bold", marginBottom: 10, color: "white" },
  dayCard: {
    flexDirection: "row",
    justifyContent: "space-between",
    padding: 10,
    backgroundColor: "#ffffffaa",
    borderRadius: 8,
    marginBottom: 8,
  },
});
