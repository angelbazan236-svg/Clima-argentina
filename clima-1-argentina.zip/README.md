# ☀️ Clima Argentina

Aplicación móvil creada con **React Native + Expo** para consultar el clima en distintas ciudades de Argentina.

### Funcionalidades
- Buscar ciudades en Argentina.
- Ver temperatura actual, humedad y viento.
- Pronóstico de varios días con iconos y colores.

### Tecnologías
- Expo
- React Native
- Open-Meteo API
